package precompiles
import("runtime";"runtime/debug")
var gl3DiagnosticForceGC="0"
func gl3DiagnosticMemory(left uint32){
 if left%64!=0 && left!=1{return}
 if gl3DiagnosticForceGC=="1"{runtime.GC()}
 var m runtime.MemStats;runtime.ReadMemStats(&m)
 println("GL3_DIAG_MEM left",left,"limit",debug.SetMemoryLimit(-1),"heapAlloc",m.HeapAlloc,"heapInuse",m.HeapInuse,"heapSys",m.HeapSys,"heapIdle",m.HeapIdle,"heapReleased",m.HeapReleased,"sys",m.Sys,"nextGC",m.NextGC,"numGC",m.NumGC,"totalAlloc",m.TotalAlloc,"heapObjects",m.HeapObjects)
}
